#include "Tanh.hpp"

float Tanh::activacion(float x) const {
        return std::tanh(x);
    }