#include "lineal.hpp"

float Lineal::activacion(float y) const {
    return y;
}
